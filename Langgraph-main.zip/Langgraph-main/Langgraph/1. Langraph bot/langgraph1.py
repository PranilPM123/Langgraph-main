from typing import TypedDict
from langgraph.graph import StateGraph, START, END

# --- 1. Define the State ---
# Think of this as the "Context" or "Memory" passed between functions.
class MyState(TypedDict):
    current_text: str
    step_count: int

# --- 2. Define the Nodes ---
# Nodes are just Python functions. They receive the State and return a dictionary with UPDATES.

def first_node(state: MyState):
    print("--- Executing Node 1 ---")
    # Logic: Add "Hello" to text and increment count
    new_text = state['current_text'] + " Hello"
    new_count = state['step_count'] + 1
    return {"current_text": new_text, "step_count": new_count}

def second_node(state: MyState):
    print("--- Executing Node 2 ---")
    # Logic: Add "World" to text and increment count
    new_text = state['current_text'] + " World"
    new_count = state['step_count'] + 1
    return {"current_text": new_text, "step_count": new_count}

# --- 3. Build the Graph ---
builder = StateGraph(MyState)

# Add nodes to the graph
builder.add_node("node_1", first_node)
builder.add_node("node_2", second_node)

# Add edges (the connections)
builder.add_edge(START, "node_1")  # Start -> Node 1
builder.add_edge("node_1", "node_2") # Node 1 -> Node 2
builder.add_edge("node_2", END)    # Node 2 -> End

# Compile the graph (this freezes the structure)
graph = builder.compile()

# --- 4. Run It ---
initial_input = {"current_text": "Start:", "step_count": 0}
result = graph.invoke(initial_input)

print("\n--- Final Result ---")
print(result)